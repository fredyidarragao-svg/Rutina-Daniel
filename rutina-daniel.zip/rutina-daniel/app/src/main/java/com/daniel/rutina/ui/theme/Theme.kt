package com.daniel.rutina.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.daniel.rutina.R

/** Fredoka: letra redondeada y amigable, fácil de leer para un niño. */
val Fredoka = FontFamily(
    Font(R.font.fredoka_medium, FontWeight.Normal),
    Font(R.font.fredoka_medium, FontWeight.Medium),
    Font(R.font.fredoka_bold, FontWeight.SemiBold),
    Font(R.font.fredoka_bold, FontWeight.Bold),
    Font(R.font.fredoka_bold, FontWeight.ExtraBold)
)

private val Base = Typography()

private val TipografiaNino = Typography(
    displayLarge = Base.displayLarge.copy(fontFamily = Fredoka),
    displayMedium = Base.displayMedium.copy(fontFamily = Fredoka),
    displaySmall = Base.displaySmall.copy(fontFamily = Fredoka),
    headlineLarge = Base.headlineLarge.copy(fontFamily = Fredoka),
    headlineMedium = Base.headlineMedium.copy(fontFamily = Fredoka),
    headlineSmall = Base.headlineSmall.copy(fontFamily = Fredoka),
    titleLarge = Base.titleLarge.copy(fontFamily = Fredoka),
    titleMedium = Base.titleMedium.copy(fontFamily = Fredoka),
    titleSmall = Base.titleSmall.copy(fontFamily = Fredoka),
    bodyLarge = Base.bodyLarge.copy(fontFamily = Fredoka),
    bodyMedium = Base.bodyMedium.copy(fontFamily = Fredoka),
    bodySmall = Base.bodySmall.copy(fontFamily = Fredoka),
    labelLarge = Base.labelLarge.copy(fontFamily = Fredoka),
    labelMedium = Base.labelMedium.copy(fontFamily = Fredoka),
    labelSmall = Base.labelSmall.copy(fontFamily = Fredoka)
)

private val EsquemaNino = lightColorScheme(
    primary = AzulAccion,
    secondary = NaranjaAlerta,
    tertiary = Morado,
    background = FondoOscuro,
    surface = Superficie,
    surfaceVariant = SuperficieClara,
    onBackground = TextoPrincipal,
    onSurface = TextoPrincipal,
    onSurfaceVariant = TextoSecundario,
    onPrimary = Color.White,
    error = RojoAlta
)

@Composable
fun RutinaDanielTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = EsquemaNino,
        typography = TipografiaNino,
        content = content
    )
}
