package com.daniel.rutina.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.daniel.rutina.data.Exercise
import com.daniel.rutina.ui.theme.AzulAccion
import com.daniel.rutina.ui.theme.Amarillo
import com.daniel.rutina.ui.theme.Morado
import com.daniel.rutina.ui.theme.NaranjaAlerta
import com.daniel.rutina.ui.theme.Rosa
import com.daniel.rutina.ui.theme.Superficie
import com.daniel.rutina.ui.theme.TextoPrincipal
import com.daniel.rutina.ui.theme.Turquesa
import com.daniel.rutina.ui.theme.VerdeOk
import kotlin.random.Random

/** Versión más oscura de un color, para el "borde de abajo" que da el efecto 3D. */
fun oscurecer(c: Color, factor: Float = 0.72f): Color =
    Color(red = c.red * factor, green = c.green * factor, blue = c.blue * factor, alpha = c.alpha)

/**
 * Botón grande con efecto 3D: tiene una base más oscura debajo y, al tocarlo, la parte de arriba
 * "se hunde". Pensado para que un niño lo vea y lo quiera tocar.
 */
@Composable
fun Boton3D(
    texto: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    emoji: String? = null,
    alto: Dp = 62.dp,
    colorTexto: Color = Color.White,
    estiloTexto: TextStyle = MaterialTheme.typography.titleLarge
) {
    val interaccion = remember { MutableInteractionSource() }
    val presionado by interaccion.collectIsPressedAsState()
    val profundidad = 6.dp
    val desplazamiento by animateDpAsState(
        targetValue = if (presionado && enabled) profundidad else 0.dp,
        label = "boton3d"
    )
    val base = if (enabled) color else Color(0xFFC3CEDD)
    val forma = RoundedCornerShape(20.dp)

    Box(
        modifier = modifier
            .height(alto + profundidad)
            .clickable(
                interactionSource = interaccion,
                indication = null,
                enabled = enabled,
                onClick = onClick
            )
    ) {
        // Base oscura (el "grosor" del botón)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(alto)
                .align(Alignment.BottomCenter)
                .clip(forma)
                .background(oscurecer(base))
        )
        // Cara del botón
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(alto)
                .offset(y = desplazamiento)
                .clip(forma)
                .background(base)
                .border(2.dp, Color.White.copy(alpha = 0.35f), forma),
            contentAlignment = Alignment.Center
        ) {
            // Brillo en la mitad de arriba
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(alto / 2)
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.16f))
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp)
            ) {
                if (emoji != null) {
                    Text(emoji, fontSize = 24.sp)
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    texto,
                    color = if (enabled) colorTexto else Color.White,
                    style = estiloTexto,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/** Tarjeta redondeada con borde inferior grueso (efecto 3D). */
@Composable
fun Tarjeta3D(
    modifier: Modifier = Modifier,
    color: Color = Superficie,
    colorBorde: Color = oscurecer(color, 0.85f),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val forma = RoundedCornerShape(24.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(forma)
            .background(colorBorde)
            .padding(bottom = 6.dp)
    ) {
        val base = Modifier
            .fillMaxWidth()
            .clip(forma)
            .background(color)
        Column(
            modifier = (if (onClick != null) base.clickable(onClick = onClick) else base).padding(16.dp),
            content = content
        )
    }
}

/** Etiqueta pequeña tipo "pastilla" (ej. "3 x 10"). */
@Composable
fun Pastilla(texto: String, color: Color, colorTexto: Color = Color.White) {
    Text(
        texto,
        color = colorTexto,
        fontWeight = FontWeight.Bold,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

/** Miniatura del ejercicio: primero el dibujo de la app, si no la foto, si no un emoji. */
@Composable
fun ExerciseThumb(ejercicio: Exercise?, tamano: Dp) {
    val color = CategoryVisuals.colorFor(ejercicio?.categoria ?: "")
    val local = ejercicio?.let { CategoryVisuals.localDrawableFor(it.id) }
    val url = ejercicio?.imagenUrl
    Box(
        modifier = Modifier
            .size(tamano)
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.14f))
            .border(3.dp, color.copy(alpha = 0.55f), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) {
        when {
            local != null -> Image(
                painter = painterResource(local),
                contentDescription = ejercicio?.nombre,
                modifier = Modifier.fillMaxSize().padding(3.dp)
            )
            url != null -> AsyncImage(
                model = url,
                contentDescription = ejercicio?.nombre,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)),
                contentScale = ContentScale.Crop
            )
            else -> Text(CategoryVisuals.emojiFor(ejercicio?.categoria ?: ""), fontSize = (tamano.value * 0.45f).sp)
        }
    }
}

/** Barra de progreso gruesa y redondeada. */
@Composable
fun BarraProgreso(hechos: Int, total: Int, colorBarra: Color = Amarillo, colorFondo: Color = Color.White.copy(alpha = 0.35f)) {
    val fraccion = if (total <= 0) 0f else (hechos.toFloat() / total).coerceIn(0f, 1f)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(22.dp)
            .clip(RoundedCornerShape(50))
            .background(colorFondo)
    ) {
        if (fraccion > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraccion)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(50))
                    .background(colorBarra)
            )
        }
    }
}

/** Emoji que "late" (crece y se encoge) para celebrar. */
@Composable
fun EmojiAnimado(emoji: String, tamano: Int = 72) {
    val transicion = rememberInfiniteTransition(label = "latido")
    val escala by transicion.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "escala"
    )
    Text(
        emoji,
        fontSize = tamano.sp,
        modifier = Modifier.graphicsLayer {
            scaleX = escala
            scaleY = escala
        }
    )
}

private val coloresConfeti = listOf(AzulAccion, Amarillo, Rosa, VerdeOk, Morado, NaranjaAlerta, Turquesa)

/** Confeti cayendo, se dibuja encima de una tarjeta de celebración. */
@Composable
fun Confeti(modifier: Modifier = Modifier) {
    val transicion = rememberInfiniteTransition(label = "confeti")
    val t by transicion.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "caida"
    )
    val piezas = remember {
        List(34) { Triple(Random.nextFloat(), Random.nextFloat(), coloresConfeti[it % coloresConfeti.size]) }
    }
    Canvas(modifier = modifier) {
        piezas.forEach { (x, fase, c) ->
            val y = ((t + fase) % 1f) * size.height
            drawRoundRect(
                color = c,
                topLeft = Offset(x * size.width, y),
                size = Size(12f, 20f),
                cornerRadius = CornerRadius(4f, 4f)
            )
        }
    }
}

/** Tarjeta de "¡Lo lograste!" con trofeo y confeti. */
@Composable
fun Celebracion(titulo: String, mensaje: String) {
    Box {
        Tarjeta3D(color = Amarillo) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                EmojiAnimado("🏆", 76)
                Text(titulo, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextoPrincipal, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                Text(mensaje, style = MaterialTheme.typography.titleMedium, color = TextoPrincipal, textAlign = TextAlign.Center)
            }
        }
        Confeti(Modifier.matchParentSize())
    }
}

/** Frase para animar según cuánto lleva. */
fun fraseAnimo(hechos: Int, total: Int): String {
    if (total == 0) return "¡A moverse! 🚀"
    val f = hechos.toFloat() / total
    return when {
        hechos == 0 -> "¡A calentar motores! 🚀"
        f < 0.5f -> "¡Vas muy bien, Daniel! 💪"
        f < 1f -> "¡Ya casi lo logras! 🔥"
        else -> "¡Rutina completa! 🏆"
    }
}

/** Contenedor de ancho completo con color de fondo suave y bordes redondeados. */
@Composable
fun Aviso(texto: String, color: Color) {
    Text(
        texto,
        color = TextoPrincipal,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(color.copy(alpha = 0.18f))
            .border(2.dp, color.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            .padding(14.dp)
    )
}

/** Cuadro de logro (estrellas, racha) con número grande. */
@Composable
fun CuadroLogro(emoji: String, valor: String, etiqueta: String, color: Color, modifier: Modifier = Modifier) {
    Tarjeta3D(modifier = modifier, color = color) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(valor, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(etiqueta, color = Color.White, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
