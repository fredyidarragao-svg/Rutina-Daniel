package com.daniel.rutina

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.daniel.rutina.ui.DayDetailScreen
import com.daniel.rutina.ui.HistoryScreen
import com.daniel.rutina.ui.LibraryScreen
import com.daniel.rutina.ui.SettingsScreen
import com.daniel.rutina.ui.WeekScreen
import com.daniel.rutina.ui.theme.RutinaDanielTheme

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RutinaDanielTheme {
                RutinaDanielApp(viewModel)
            }
        }
    }
}

@Composable
fun RutinaDanielApp(viewModel: AppViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = "semana") {
        composable("semana") {
            WeekScreen(
                viewModel = viewModel,
                onDayClick = { dayId -> navController.navigate("dia/$dayId") },
                onLibraryClick = { navController.navigate("biblioteca") },
                onHistoryClick = { navController.navigate("historial") },
                onSettingsClick = { navController.navigate("ajustes") }
            )
        }
        composable("ajustes") {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("historial") {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("dia/{dayId}") { backStackEntry ->
            val dayId = backStackEntry.arguments?.getString("dayId") ?: return@composable
            DayDetailScreen(
                viewModel = viewModel,
                dayId = dayId,
                onBack = { navController.popBackStack() }
            )
        }
        composable("biblioteca") {
            LibraryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
