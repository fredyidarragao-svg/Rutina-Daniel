package com.daniel.rutina.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daniel.rutina.AppViewModel
import com.daniel.rutina.data.DayPlan
import com.daniel.rutina.data.RoutineData
import com.daniel.rutina.ui.theme.*

@Composable
fun WeekScreen(
    viewModel: AppViewModel,
    onDayClick: (String) -> Unit,
    onLibraryClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val fatigaAlta by viewModel.fatigaAlta.collectAsState()
    val estrellas by viewModel.estrellas.collectAsState()
    val racha by viewModel.racha.collectAsState()
    val semanaHecha by viewModel.semanaHecha.collectAsState()
    var mostrarTracking by remember { mutableStateOf(false) }

    val hoyId = viewModel.todayDayId()
    val hoy = RoutineData.weeklyPlan.first { it.id == hoyId }
    val hoyHecho = semanaHecha.contains(hoyId)

    Scaffold(containerColor = FondoOscuro) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---- Saludo ----
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "¡Hola, Daniel! 👋",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextoPrincipal
                        )
                        Text(
                            if (hoy.esDeporte) "Hoy te toca ${hoy.deporte} 💪" else "Hoy es día de estirar y descansar 🧘",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextoSecundario
                        )
                    }
                    TextButton(onClick = onSettingsClick) { Text("⚙️", fontSize = 26.sp) }
                }
            }

            // ---- Logros ----
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CuadroLogro("⭐", "$estrellas", if (estrellas == 1) "estrella" else "estrellas", NaranjaAlerta, Modifier.weight(1f))
                    CuadroLogro("🔥", "$racha", if (racha == 1) "día seguido" else "días seguidos", RojoAlta, Modifier.weight(1f))
                }
            }

            if (fatigaAlta) {
                item {
                    Aviso("😴 Tu corazón trabajó mucho estos días. Hoy mejor algo suave: estiramientos y a descansar.", NaranjaAlerta)
                }
            }

            // ---- Tarjeta grande de HOY ----
            item {
                val colorHoy = CategoryVisuals.colorDia(hoyId)
                Tarjeta3D(color = colorHoy) {
                    Text(
                        "HOY • ${hoy.dia}",
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        EmojiAnimado(CategoryVisuals.emojiDia(hoy.deporte, hoy.esDeporte), 58)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                hoy.titulo,
                                color = Color.White,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(hoy.subtitulo, color = Color.White, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (hoyHecho) {
                        Text(
                            "✅ ¡Ya completaste hoy! Ganaste una ⭐",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    Boton3D(
                        texto = if (hoyHecho) "Ver mi día" else "¡Vamos!",
                        emoji = if (hoyHecho) "👀" else "🚀",
                        color = Amarillo,
                        colorTexto = TextoPrincipal,
                        onClick = { onDayClick(hoyId) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // ---- Semana ----
            item {
                Text(
                    "Mi semana 📅",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextoPrincipal,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            items(RoutineData.weeklyPlan) { day ->
                DiaCard(
                    day = day,
                    hecho = semanaHecha.contains(day.id),
                    esHoy = day.id == hoyId,
                    onClick = { onDayClick(day.id) }
                )
            }

            // ---- Botones de abajo ----
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Boton3D("Ejercicios", Morado, onLibraryClick, Modifier.weight(1f), emoji = "📚",
                        estiloTexto = MaterialTheme.typography.titleMedium)
                    Boton3D("Mis logros", Turquesa, onHistoryClick, Modifier.weight(1f), emoji = "🏆",
                        estiloTexto = MaterialTheme.typography.titleMedium)
                }
            }
            item {
                TextButton(onClick = { mostrarTracking = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("⌚ Datos del reloj (para papá)", color = TextoSecundario, style = MaterialTheme.typography.titleSmall)
                }
            }
        }
    }

    if (mostrarTracking) {
        TrackingSheet(
            viewModel = viewModel,
            dayId = viewModel.todayDayId(),
            onDismiss = { mostrarTracking = false }
        )
    }
}

@Composable
private fun DiaCard(day: DayPlan, hecho: Boolean, esHoy: Boolean, onClick: () -> Unit) {
    val color = CategoryVisuals.colorDia(day.id)
    Tarjeta3D(
        color = if (hecho) Color(0xFFE3F8E8) else Superficie,
        colorBorde = if (esHoy) color else if (hecho) VerdeOk else SuperficieClara,
        onClick = onClick
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(color),
                contentAlignment = Alignment.Center
            ) {
                Text(CategoryVisuals.emojiDia(day.deporte, day.esDeporte), fontSize = 28.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    day.dia + if (esHoy) "  • HOY" else "",
                    color = color,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(day.titulo, color = TextoPrincipal, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text(day.duracion, color = TextoSecundario, style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                when {
                    hecho -> "✅"
                    esHoy -> "👉"
                    else -> ""
                },
                fontSize = 30.sp
            )
        }
    }
}
