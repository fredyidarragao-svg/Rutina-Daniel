package com.daniel.rutina.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daniel.rutina.AppViewModel
import com.daniel.rutina.data.PlanItem
import com.daniel.rutina.data.RoutineData
import com.daniel.rutina.ui.theme.*
import java.net.URLEncoder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayDetailScreen(
    viewModel: AppViewModel,
    dayId: String,
    onBack: () -> Unit
) {
    val day = RoutineData.weeklyPlan.find { it.id == dayId } ?: return
    val altToggles by viewModel.altToggles.collectAsState()
    val usaAlt = altToggles[dayId] == true
    val tracking by viewModel.todayTracking.collectAsState()
    val fatigaAlta by viewModel.fatigaAlta.collectAsState()
    var mostrarTracking by remember { mutableStateOf(false) }
    val esHoy = dayId == viewModel.todayDayId()

    // Día de deporte sin activar "hoy no patiné": solo se marca el deporte, no hay rutina.
    val soloDeporte = day.esDeporte && !usaAlt
    val plan = viewModel.activePlanFor(dayId)
    val titulo = viewModel.activeTitleFor(dayId)
    val subtitulo = if (day.esDeporte && usaAlt) {
        RoutineData.altRoutines[day.planAlternativoId]?.subtitulo ?: day.subtitulo
    } else day.subtitulo
    val completados = if (esHoy) viewModel.completedIndices() else emptySet()
    val progreso = completados.count { it < plan.size }
    val rutinaCompleta = plan.isNotEmpty() && progreso >= plan.size
    val actividadHecha = esHoy && tracking?.actividadHecha == true
    val colorDia = CategoryVisuals.colorDia(dayId)
    val emojiDia = CategoryVisuals.emojiDia(day.deporte, day.esDeporte)
    val verbo = if (day.deporte == "natación") "nadé" else "patiné"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("$emojiDia ${day.dia}", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = FondoOscuro)
            )
        },
        containerColor = FondoOscuro
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!esHoy) {
                item {
                    Aviso("👀 Esto es para mirar. Podrás marcarlo el ${day.dia.lowercase()}.", AzulAccion)
                }
            }

            if (fatigaAlta) {
                item {
                    Aviso("😴 Tu corazón trabajó mucho estos días. Hoy mejor algo suave y descansar bien.", NaranjaAlerta)
                }
            }

            if (soloDeporte) {
                // ---------------- Día de deporte: solo marcar ----------------
                item {
                    Box {
                        Tarjeta3D(color = if (actividadHecha) VerdeOk else colorDia) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                EmojiAnimado(if (actividadHecha) "🏆" else emojiDia, 80)
                                Text(
                                    if (actividadHecha) "¡Súper, Daniel!" else "¡Hoy toca ${day.deporte}!",
                                    color = Color.White,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    if (actividadHecha) "Entreno completado. ¡Ganaste una ⭐!"
                                    else if (day.minutosDeporte != null) "⏱ ${day.duracion} de entreno"
                                    else day.subtitulo,
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium,
                                    textAlign = TextAlign.Center
                                )
                            }
                            Spacer(Modifier.height(16.dp))
                            Boton3D(
                                texto = if (actividadHecha) "¡Ya $verbo!" else "¡Ya $verbo!",
                                emoji = if (actividadHecha) "✅" else "🙌",
                                color = if (actividadHecha) Color(0xFF178A38) else Amarillo,
                                colorTexto = if (actividadHecha) Color.White else TextoPrincipal,
                                enabled = esHoy,
                                onClick = { viewModel.toggleActividadHecha(dayId, 0) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (actividadHecha) {
                                Text(
                                    "Toca otra vez si lo marcaste por error",
                                    color = Color.White.copy(alpha = 0.85f),
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                        if (actividadHecha) Confeti(Modifier.matchParentSize())
                    }
                }
                if (!actividadHecha) {
                    item {
                        Tarjeta3D {
                            Text(
                                "¿Hoy no hubo ${day.deporte}? 🤔",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextoPrincipal
                            )
                            Text(
                                "No pasa nada: hacemos una rutina divertida en casa.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextoSecundario
                            )
                            Spacer(Modifier.height(12.dp))
                            Boton3D(
                                texto = "Hoy no $verbo",
                                emoji = "🏠",
                                color = NaranjaAlerta,
                                onClick = { viewModel.toggleAlt(dayId) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            } else {
                // ---------------- Rutina (en casa o estiramientos) ----------------
                if (day.esDeporte) {
                    item {
                        Tarjeta3D(color = Color(0xFFFFF4D6), colorBorde = Amarillo) {
                            Text(
                                "🏠 Rutina en casa porque hoy no $verbo.",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextoPrincipal
                            )
                            TextButton(onClick = { viewModel.toggleAlt(dayId) }) {
                                Text("↩ Sí $verbo, volver", color = AzulAccion, style = MaterialTheme.typography.titleSmall)
                            }
                        }
                    }
                }

                item {
                    Tarjeta3D(color = colorDia) {
                        Text(titulo, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(subtitulo, color = Color.White, style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.height(12.dp))
                        BarraProgreso(progreso, plan.size)
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "⭐ $progreso de ${plan.size}",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(fraseAnimo(progreso, plan.size), color = Color.White, style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }

                if (rutinaCompleta && esHoy) {
                    item {
                        Celebracion("¡Lo lograste, Daniel!", "Rutina completa. ¡Eres un campeón! ⭐")
                    }
                }

                itemsIndexed(plan) { index, item ->
                    EjercicioCard(
                        numero = index + 1,
                        item = item,
                        hecho = completados.contains(index),
                        habilitado = esHoy,
                        onToggleHecho = { viewModel.toggleExerciseDone(dayId, index, plan.size, false) }
                    )
                }
            }

            item {
                TextButton(
                    onClick = { mostrarTracking = true },
                    enabled = esHoy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (esHoy) "⌚ Registrar datos del reloj (papá)" else "⌚ Datos del reloj: solo el mismo día",
                        color = TextoSecundario,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }

            tracking?.let { t ->
                if (esHoy && (t.fcAvg != null || t.pasos != null || t.calorias != null || t.fcReposo != null || t.sinActividad)) {
                    item {
                        MetricsSummary(
                            t.fcReposo, t.fcAvg, t.fcMax, t.calorias, t.tiempoMin,
                            t.distanciaKm, t.suenoHoras, t.pasos, t.fuenteAuto, t.sinActividad
                        )
                    }
                }
            }
        }
    }

    if (mostrarTracking) {
        TrackingSheet(
            viewModel = viewModel,
            dayId = dayId,
            onDismiss = { mostrarTracking = false }
        )
    }
}

private val numerosEmoji = listOf("1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣")

@Composable
private fun EjercicioCard(
    numero: Int,
    item: PlanItem,
    hecho: Boolean,
    habilitado: Boolean,
    onToggleHecho: () -> Unit
) {
    val ejercicio = RoutineData.exerciseById(item.idLib)
    val colorCat = CategoryVisuals.colorFor(ejercicio?.categoria ?: "")
    var expandido by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Tarjeta3D(
        color = if (hecho) Color(0xFFE3F8E8) else Superficie,
        colorBorde = if (hecho) VerdeOk else SuperficieClara,
        onClick = { expandido = !expandido }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ExerciseThumb(ejercicio, 88.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "$numero. ${ejercicio?.nombre ?: item.idLib}",
                    color = TextoPrincipal,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(6.dp))
                Pastilla(item.series, colorCat)
                if (item.descanso != "-") {
                    Spacer(Modifier.height(4.dp))
                    Text("😮‍💨 Descanso ${item.descanso}", color = TextoSecundario, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        if (!expandido) {
            Text(
                "👆 Toca para ver cómo se hace",
                color = AzulAccion,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (expandido && ejercicio != null) {
            Spacer(Modifier.height(10.dp))
            ejercicio.bullets.forEachIndexed { i, paso ->
                Row(modifier = Modifier.padding(vertical = 3.dp)) {
                    Text(numerosEmoji.getOrElse(i) { "▶️" }, fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(paso, color = TextoPrincipal, style = MaterialTheme.typography.bodyLarge)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("💡 ${ejercicio.tecnica}", color = TextoSecundario, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            Text("⚠️ Cuidado: ${item.cuidado}", color = RojoAlta, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            if (ejercicio.usaPesas) {
                Text("🏋️ Peso ligero (pídele ayuda a papá)", color = NaranjaAlerta, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = {
                val query = URLEncoder.encode(ejercicio.nombre + " ejercicio niños", "UTF-8")
                val url = "https://www.youtube.com/results?search_query=$query"
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }) {
                Text("▶️ Ver video", color = AzulAccion, style = MaterialTheme.typography.titleSmall)
            }
        }

        Spacer(Modifier.height(10.dp))
        Boton3D(
            texto = if (hecho) "¡Hecho!" else if (habilitado) "¡Lo hice!" else "Solo el mismo día",
            emoji = if (hecho) "⭐" else if (habilitado) "💪" else "📅",
            color = if (hecho) VerdeOk else AzulAccion,
            enabled = habilitado,
            alto = 54.dp,
            onClick = onToggleHecho,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun MetricsSummary(
    fcReposo: Int?, fcAvg: Int?, fcMax: Int?, calorias: Int?, tiempoMin: Int?,
    distanciaKm: Double?, suenoHoras: Double?, pasos: Int?, fuenteAuto: Boolean, sinActividad: Boolean
) {
    Tarjeta3D {
        Text(
            if (fuenteAuto) "⌚ Desde el reloj" else "✍️ Registro manual",
            color = TextoSecundario, style = MaterialTheme.typography.labelLarge
        )
        if (sinActividad) {
            Text("Día sin actividad física (registrado)", color = NaranjaAlerta, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        val filas = listOfNotNull(
            fcReposo?.let { "❤️ FC en reposo: $it" },
            fcAvg?.let { "💓 FC promedio: $it" },
            fcMax?.let { "📈 FC máx: $it" },
            calorias?.let { "🔥 Calorías: $it" },
            tiempoMin?.let { "⏱ Tiempo: $it min" },
            distanciaKm?.let { "📏 Distancia: $it km" },
            suenoHoras?.let { "😴 Sueño: $it h" },
            pasos?.let { "👣 Pasos: $it" }
        )
        filas.forEach { Text(it, color = TextoPrincipal, style = MaterialTheme.typography.bodyLarge) }
    }
}
