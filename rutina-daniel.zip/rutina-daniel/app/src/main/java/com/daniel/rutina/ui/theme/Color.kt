package com.daniel.rutina.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta clara y alegre para Daniel (los nombres se mantienen del modelo original).
val FondoOscuro = Color(0xFFE6F4FF)      // fondo cielo
val Superficie = Color(0xFFFFFFFF)       // tarjetas
val SuperficieClara = Color(0xFFD5EAFB)  // botones apagados / bordes
val AzulAccion = Color(0xFF2E86FF)
val VerdeOk = Color(0xFF22B84C)
val NaranjaAlerta = Color(0xFFFF9F1C)
val RojoAlta = Color(0xFFFF4D6D)
val TextoPrincipal = Color(0xFF1B2A4A)
val TextoSecundario = Color(0xFF5B6B88)

// Colores extra para el modo niño
val Morado = Color(0xFF8E5CFF)
val Amarillo = Color(0xFFFFC93C)
val Turquesa = Color(0xFF00BFA6)
val Rosa = Color(0xFFFF6FB5)
