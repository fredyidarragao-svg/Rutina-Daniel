package com.daniel.rutina.data

/**
 * Rutina de Daniel: niño deportista de 7 años (1,40 m, 30 kg).
 *
 * Semana real:
 *  - Patinaje lunes, martes, miércoles, jueves y sábado.
 *  - Natación el domingo.
 *  - Viernes: descanso (solo estiramientos opcionales).
 *
 * Reglas con las que se armó todo:
 *  - Días de deporte: solo se marca que Daniel hizo el deporte (sin rutina extra).
 *  - Si Daniel NO practica el deporte ese día (botón "Hoy no patiné"), se genera una
 *    rutina en casa que SÍ incluye fortalecimiento de piernas + off-skate + tren superior.
 *  - Duración 30–45 min. Calentamiento funcional (no alcanza la bici estática).
 *  - Equipo: mancuernas y pesas de mano/pie (muñequeras/tobilleras). Siempre peso LIGERO:
 *    mancuernas 0,5–1 kg (máximo 2 kg) y tobilleras/muñequeras de 0,5 kg. En un niño de 7
 *    años manda la técnica, no el peso: si la forma se pierde, se termina la serie.
 *  - Los slots ROT_* cambian cada semana (ciclo de 4) para que la rutina no sea siempre igual.
 */
object RoutineData {

    // ---------------------------------------------------------------------------------------
    // Bloques reutilizables
    // ---------------------------------------------------------------------------------------

    /** Calentamiento funcional completo (días sin patinaje): sí incluye saltos suaves. */
    private val calentamientoCompleto = listOf(
        PlanItem("movilidad", "3 min", "-", "Articulaciones de arriba hacia abajo", "Suave"),
        PlanItem("jumping-jacks", "2x30s", "20s", "Ritmo cómodo", "Cae en puntas suave"),
        PlanItem("skipping", "2x20s", "20s", "Rodillas a la cadera", "Brazos acompañan"),
        PlanItem("talones-gluteo", "2x20s", "20s", "Talón toca glúteo", "Suave"),
        PlanItem("gateo-oso", "2x20s", "20s", "Adelante y atrás", "Rodillas cerca del piso")
    )

    private val vueltaCalmaPiernas = PlanItem("estiramiento-piernas", "5 min", "-", "Cuádriceps, isquios, glúteo, aductor, gemelo", "Mantén 20s cada uno")

    // ---------------------------------------------------------------------------------------
    // Semana
    // ---------------------------------------------------------------------------------------

    /**
     * Días de deporte: NO tienen rutina. Solo se marca "¡Ya patiné!" (o "¡Ya nadé!").
     * Si Daniel no practicó, el botón "Hoy no patiné" genera la rutina en casa (altRoutines).
     */
    val weeklyPlan: List<DayPlan> = listOf(
        DayPlan(
            id = "lun", dia = "LUNES", titulo = "PATINAJE", subtitulo = "Entreno de patinaje",
            duracion = "90 min", intensidad = "ALTA", deporte = "patinaje", esDeporte = true,
            planNormal = emptyList(),
            planAlternativoId = "LUN_ALT",
            minutosDeporte = 90
        ),
        DayPlan(
            id = "mar", dia = "MARTES", titulo = "PATINAJE", subtitulo = "Entreno de patinaje",
            duracion = "90 min", intensidad = "ALTA", deporte = "patinaje", esDeporte = true,
            planNormal = emptyList(),
            planAlternativoId = "MAR_ALT",
            minutosDeporte = 90
        ),
        DayPlan(
            id = "mie", dia = "MIÉRCOLES", titulo = "PATINAJE", subtitulo = "Entreno de patinaje",
            duracion = "90 min", intensidad = "MEDIA", deporte = "patinaje", esDeporte = true,
            planNormal = emptyList(),
            planAlternativoId = "MIE_ALT",
            minutosDeporte = 90
        ),
        DayPlan(
            id = "jue", dia = "JUEVES", titulo = "PATINAJE", subtitulo = "Entreno de patinaje",
            duracion = "90 min", intensidad = "ALTA", deporte = "patinaje", esDeporte = true,
            planNormal = emptyList(),
            planAlternativoId = "JUE_ALT",
            minutosDeporte = 90
        ),
        DayPlan(
            id = "vie", dia = "VIERNES", titulo = "ESTIRAMIENTOS", subtitulo = "Día de descanso: estirar y relajarse",
            duracion = "20 min", intensidad = "SUAVE", deporte = null, esDeporte = false,
            planNormal = listOf(
                PlanItem("movilidad", "4 min", "-", "Movilidad general", "Muy suave"),
                PlanItem("estiramiento-piernas", "6 min", "-", "Las piernas trabajaron toda la semana", "Mantén 20-30s"),
                PlanItem("estiramiento", "5 min", "-", "Brazos, pecho y espalda", "Respira lento"),
                PlanItem("cangrejo", "2x15s", "20s", "Suave, para soltar hombros", "Sin prisa")
            ),
            planAlternativoId = "VIE_ALT"
        ),
        DayPlan(
            id = "sab", dia = "SÁBADO", titulo = "PATINAJE", subtitulo = "Entreno de patinaje",
            duracion = "90 min", intensidad = "MEDIA", deporte = "patinaje", esDeporte = true,
            planNormal = emptyList(),
            planAlternativoId = "SAB_ALT",
            minutosDeporte = 90
        ),
        DayPlan(
            id = "dom", dia = "DOMINGO", titulo = "NATACIÓN", subtitulo = "Clase de natación",
            duracion = "Natación", intensidad = "SUAVE", deporte = "natación", esDeporte = true,
            planNormal = emptyList(),
            planAlternativoId = "DOM_ALT"
        )
    )

    // ---------------------------------------------------------------------------------------
    // Rutinas generadas cuando Daniel NO practica el deporte ese día (35-45 min).
    // Incluyen piernas + off-skate (activación / quema de grasa) + tren superior.
    // ---------------------------------------------------------------------------------------

    val altRoutines: Map<String, AltRoutine> = mapOf(
        "LUN_ALT" to AltRoutine(
            titulo = "LUNES EN CASA • Off-skate + Piernas + Brazos",
            subtitulo = "No hubo patinaje → 40 min",
            ejercicios = calentamientoCompleto + listOf(
                PlanItem("ROT_OFFSKATE", "3x20-30s", "40s", "(cambia cada semana)", ""),
                PlanItem("ROT_PIERNA", "3x10-12", "60s", "(cambia cada semana)", ""),
                PlanItem("puente-gluteo", "3x12", "45s", "Glúteo = empuje del patín", "Aprieta 2s arriba"),
                PlanItem("ROT_EMPUJE", "3x8-10", "60s", "(cambia cada semana)", ""),
                PlanItem("ROT_BICEPS", "2x10-12", "45s", "(cambia cada semana)", ""),
                PlanItem("ROT_CORE", "3x20-30s", "40s", "(cambia cada semana)", ""),
                vueltaCalmaPiernas
            )
        ),
        "MAR_ALT" to AltRoutine(
            titulo = "MARTES EN CASA • Quema off-skate + Espalda",
            subtitulo = "No hubo patinaje → circuito 40 min",
            ejercicios = calentamientoCompleto + listOf(
                PlanItem("os-patinador", "3x20s", "40s", "Saltos laterales de patinador", "Cae suave, rodilla sobre el pie"),
                PlanItem("os-sentadilla-lateral", "3x8 c/lado", "45s", "Desplazamiento lateral", "Pecho arriba"),
                PlanItem("escalador", "3x20s", "40s", "Quema + abdomen", "Ritmo controlado"),
                PlanItem("ROT_TIRON", "3x10-12", "45s", "(cambia cada semana)", ""),
                PlanItem("patada-lateral-tob", "2x10 c/lado", "40s", "Glúteo medio = estabilidad", "Tobillera 0,5 kg"),
                PlanItem("superman", "2x8", "40s", "Espalda baja", "Sin balanceo"),
                vueltaCalmaPiernas
            )
        ),
        "MIE_ALT" to AltRoutine(
            titulo = "MIÉRCOLES EN CASA • Piernas fuertes + Hombros",
            subtitulo = "No hubo patinaje → 40 min",
            ejercicios = calentamientoCompleto + listOf(
                PlanItem("os-posicion", "3x20-30s", "40s", "Posición baja de patinaje", "Espalda plana"),
                PlanItem("sentadilla", "3x12", "60s", "Peso corporal", "Rodillas siguen la punta del pie"),
                PlanItem("zancada-atras", "2x8 c/pierna", "60s", "Sin peso o 0,5 kg", "Tronco recto"),
                PlanItem("pantorrilla", "3x15", "40s", "Tobillo fuerte", "Lento abajo"),
                PlanItem("ROT_HOMBRO", "3x10", "45s", "(cambia cada semana)", ""),
                PlanItem("ROT_TRICEPS", "2x10", "45s", "(cambia cada semana)", ""),
                PlanItem("ROT_CORE2", "3x10-12", "40s", "(cambia cada semana)", ""),
                vueltaCalmaPiernas
            )
        ),
        "JUE_ALT" to AltRoutine(
            titulo = "JUEVES EN CASA • Equilibrio off-skate + Core",
            subtitulo = "No hubo patinaje → 40 min",
            ejercicios = calentamientoCompleto + listOf(
                PlanItem("os-equilibrio", "3x20s c/pierna", "30s", "Equilibrio en 1 pierna", "Cerca de una pared"),
                PlanItem("ROT_PIERNA", "3x10-12", "60s", "(cambia cada semana)", ""),
                PlanItem("puente-1pierna", "2x8 c/pierna", "45s", "Glúteo unilateral", "Cadera nivelada"),
                PlanItem("ROT_TIRON", "3x10-12", "45s", "(cambia cada semana)", ""),
                PlanItem("hollow", "3x15-20s", "40s", "'Banana'", "Lumbar pegada"),
                PlanItem("russian", "2x10 c/lado", "40s", "Sin peso", "Espalda recta"),
                vueltaCalmaPiernas
            )
        ),
        "VIE_ALT" to AltRoutine(
            titulo = "VIERNES • Descanso",
            subtitulo = "Día de recuperación",
            ejercicios = emptyList()
        ),
        "SAB_ALT" to AltRoutine(
            titulo = "SÁBADO EN CASA • Circuito quema + Piernas",
            subtitulo = "No hubo patinaje → circuito 35-40 min",
            ejercicios = calentamientoCompleto + listOf(
                PlanItem("ROT_OFFSKATE", "3x20-30s", "30s", "(cambia cada semana) Circuito", ""),
                PlanItem("sentadilla-goblet", "3x10", "30s", "Circuito • mancuerna 1 kg al pecho", "Rodillas siguen la punta"),
                PlanItem("flex-inclinada", "3x8-10", "30s", "Circuito", "Cuerpo recto"),
                PlanItem("patada-atras-tob", "3x10 c/lado", "30s", "Circuito • tobillera", "Sin arquear la espalda"),
                PlanItem("escalador", "3x20s", "30s", "Circuito", "Ritmo controlado"),
                PlanItem("remo-manc", "3x12", "60s al final de la vuelta", "Circuito", "Peso ligero"),
                vueltaCalmaPiernas
            )
        ),
        "DOM_ALT" to AltRoutine(
            titulo = "DOMINGO EN CASA • Cuerpo completo",
            subtitulo = "No hubo natación → 35 min",
            ejercicios = calentamientoCompleto + listOf(
                PlanItem("ROT_PIERNA", "3x10-12", "60s", "(cambia cada semana)", ""),
                PlanItem("os-posicion", "2x20s", "40s", "Posición de patinaje", "Espalda plana"),
                PlanItem("nadador-ytw", "2x6 de cada letra", "40s", "Reemplaza la natación", "Sin peso o 0,5 kg"),
                PlanItem("ROT_EMPUJE", "3x8-10", "60s", "(cambia cada semana)", ""),
                PlanItem("dead-bug", "3x8 c/lado", "40s", "Core", "Lento"),
                vueltaCalmaPiernas
            )
        )
    )

    // ---------------------------------------------------------------------------------------
    // Rotación semanal (ciclo de 4 semanas). Índice 0 = semana 1.
    // ---------------------------------------------------------------------------------------

    val rotaciones: Map<String, List<String>> = mapOf(
        "ROT_EMPUJE" to listOf("flex-inclinada", "flex-rodillas", "fondos-silla", "flex-rodillas"),
        "ROT_TIRON" to listOf("remo-manc", "remo-un-brazo", "pajaros", "remo-manc"),
        "ROT_BICEPS" to listOf("curl-manc", "curl-martillo", "curl-manc", "curl-martillo"),
        "ROT_TRICEPS" to listOf("ext-triceps", "patada-triceps", "fondos-silla", "ext-triceps"),
        "ROT_HOMBRO" to listOf("elev-lateral", "press-hombro", "elev-frontal", "press-hombro"),
        "ROT_CORE" to listOf("plancha", "hollow", "plancha-lateral", "plancha-toques"),
        "ROT_CORE2" to listOf("crunch-inverso", "tijeras", "russian", "escalador"),
        "ROT_OFFSKATE" to listOf("os-posicion", "os-patinador", "os-sentadilla-lateral", "os-equilibrio"),
        "ROT_PIERNA" to listOf("sentadilla", "zancada-atras", "sentadilla-goblet", "puente-1pierna")
    )

    // ---------------------------------------------------------------------------------------
    // Biblioteca de ejercicios (adaptados a un niño de 7 años)
    // ---------------------------------------------------------------------------------------

    val exerciseLibrary: List<Exercise> = listOf(
        // ---- CALENTAMIENTO FUNCIONAL ----
        Exercise("movilidad", "Movilidad Articular", "Calentamiento funcional", "Todas las articulaciones",
            listOf("Círculos de cuello (suaves), hombros y brazos", "Círculos de muñecas, cadera y rodillas", "Círculos de tobillos: muy importantes para el patín"),
            "10 círculos por articulación, de arriba hacia abajo. Sube la temperatura del cuerpo sin cansarlo.",
            "Nada brusco.", "Preparar el cuerpo", "3-4 min", "CALENTAMIENTO", false),
        Exercise("jumping-jacks", "Saltos de Tijera (Jumping Jacks)", "Calentamiento + cardio", "Cuerpo completo + corazón",
            listOf("Pies juntos, brazos abajo", "Salta abriendo piernas y subiendo brazos", "Vuelve al centro y repite"),
            "Ritmo cómodo, que pueda hablar mientras salta.",
            "Cae en la punta del pie, suave.", "Activar", "2x30s", "CALENTAMIENTO", false, imagenId = "Star_Jump"),
        Exercise("skipping", "Skipping (Rodillas Arriba)", "Calentamiento + coordinación", "Cadera + core + corazón",
            listOf("Trote en el sitio", "Sube rodillas hasta la cadera", "Brazos acompañan como al correr"),
            "Coordinación de brazos y piernas, como en el patinaje.",
            "Suave en la caída.", "Coordinación", "2x20s", "CALENTAMIENTO", false),
        Exercise("talones-gluteo", "Talones al Glúteo", "Calentamiento", "Isquiotibiales + cuádriceps",
            listOf("Trote en el sitio", "Lleva el talón a tocar el glúteo", "Alterna rápido pero controlado"),
            "Prepara la parte de atrás del muslo.",
            "Suave.", "Activar piernas", "2x20s", "CALENTAMIENTO", false, imagenId = "Single_Leg_Butt_Kick"),
        Exercise("gateo-oso", "Gateo de Oso", "Calentamiento funcional", "Hombros + core + coordinación",
            listOf("Manos y pies en el piso, rodillas a 2-3 cm del suelo", "Avanza mano y pie contrarios", "Espalda plana como una mesa"),
            "Excelente para hombros y abdomen sin cargar piernas. Que sea un juego: avanzar y retroceder.",
            "Rodillas no tocan el piso.", "Fuerza de hombros y core", "3x20s", "CALENTAMIENTO", false),
        Exercise("cangrejo", "Caminata de Cangrejo", "Calentamiento funcional", "Tríceps + hombros + glúteo",
            listOf("Sentado, manos atrás con dedos hacia los pies", "Sube la cadera", "Camina hacia adelante y atrás"),
            "Activa tríceps y la espalda. Muy divertido para niños.",
            "Calienta las muñecas antes.", "Brazos y hombros", "2x20s", "CALENTAMIENTO", false),

        // ---- BRAZOS ----
        Exercise("flex-inclinada", "Flexión Inclinada (manos en sofá o silla)", "Pecho + tríceps", "Pectoral + tríceps + hombro",
            listOf("Manos en el borde del sofá o una silla firme", "Cuerpo recto de cabeza a talones", "Baja el pecho al borde y empuja"),
            "La mejor forma de empezar las flexiones. Cuando haga 3x12 perfectas, pasa a flexión con rodillas.",
            "Silla contra la pared para que no se mueva.", "Fuerza de empuje", "3x8-10 • 60s", "BRAZOS", false, imagenId = "Incline_Push-Up"),
        Exercise("flex-rodillas", "Flexión con Rodillas Apoyadas", "Pecho + tríceps", "Pectoral + tríceps + core",
            listOf("Rodillas en el piso (sobre una toalla)", "Manos un poco más abiertas que los hombros", "Baja el pecho recto, sin hundir la cadera"),
            "Si llega a 3x12 bien hechas, prueba 1-2 flexiones completas al final de cada serie.",
            "Toalla bajo las rodillas.", "Fuerza de brazos", "3x8-10 • 60s", "BRAZOS", false),
        Exercise("fondos-silla", "Fondos en Silla (Tríceps)", "Tríceps", "Tríceps + hombro",
            listOf("Manos en el borde de una silla firme, detrás de la cadera", "Rodillas dobladas, pies en el piso", "Baja doblando codos hasta 90° y sube"),
            "Codos apuntan hacia atrás, no hacia los lados.",
            "No bajar más de 90° de codo (cuida el hombro).", "Tríceps fuerte", "3x8-10 • 60s", "BRAZOS", false),
        Exercise("curl-manc", "Curl de Bíceps con Mancuernas", "Bíceps", "Bíceps + antebrazo",
            listOf("De pie, mancuernas ligeras a los lados", "Sube doblando el codo, codos pegados al cuerpo", "Baja lento contando 2"),
            "Mancuernas de 0,5–1 kg. Si balancea el cuerpo para subir, el peso es muy alto.",
            "Peso ligero siempre.", "Brazos fuertes", "3x10-12 • 45s", "BRAZOS", true, imagenId = "Dumbbell_Bicep_Curl"),
        Exercise("curl-martillo", "Curl Martillo", "Bíceps + antebrazo", "Braquial + antebrazo",
            listOf("Mancuernas con palmas mirándose", "Sube sin girar las muñecas", "Baja lento"),
            "Fortalece el agarre y el antebrazo. Peso ligero.",
            "Peso ligero siempre.", "Antebrazo fuerte", "3x10-12 • 45s", "BRAZOS", true, imagenId = "Hammer_Curls"),
        Exercise("ext-triceps", "Extensión de Tríceps Sobre la Cabeza", "Tríceps", "Tríceps",
            listOf("Sentado, una mancuerna con las dos manos sobre la cabeza", "Baja la mancuerna detrás de la cabeza doblando codos", "Sube estirando los brazos"),
            "Una sola mancuerna de 1 kg con las dos manos. Codos apuntando al techo.",
            "Un adulto cerca la primera vez.", "Tríceps", "3x10 • 45s", "BRAZOS", true, imagenId = "Seated_Triceps_Press"),
        Exercise("patada-triceps", "Patada de Tríceps", "Tríceps", "Tríceps",
            listOf("Inclinado hacia adelante, espalda recta, una mano en una silla", "Codo pegado al cuerpo", "Estira el brazo hacia atrás y aprieta"),
            "Mancuerna de 0,5–1 kg o muñequera.",
            "Espalda recta.", "Tríceps", "3x10 c/brazo • 45s", "BRAZOS", true, imagenId = "Tricep_Dumbbell_Kickback"),

        // ---- HOMBROS ----
        Exercise("elev-lateral", "Elevación Lateral", "Hombro", "Deltoide medio",
            listOf("De pie, mancuernas o muñequeras", "Sube los brazos a los lados hasta el hombro", "Baja lento"),
            "Con muñequeras de 0,5 kg queda perfecto. Nunca más arriba del hombro.",
            "Peso muy ligero.", "Hombros fuertes para el braceo", "3x10 • 45s", "HOMBROS", true, imagenId = "Side_Lateral_Raise"),
        Exercise("elev-frontal", "Elevación Frontal", "Hombro", "Deltoide anterior",
            listOf("De pie, brazos al frente con muñequeras o mancuernas ligeras", "Sube hasta la altura de los ojos", "Baja lento"),
            "Imita el braceo del patinaje. Peso muy ligero.",
            "Sin balancear el cuerpo.", "Braceo", "3x10 • 45s", "HOMBROS", true, imagenId = "Front_Dumbbell_Raise"),
        Exercise("press-hombro", "Press de Hombros Sentado", "Hombro completo", "Deltoides + tríceps",
            listOf("Sentado con la espalda contra la pared", "Mancuernas a la altura de las orejas", "Empuja arriba y baja controlado"),
            "Espalda pegada a la pared para no arquear la zona lumbar.",
            "Peso ligero.", "Hombros", "3x10 • 45s", "HOMBROS", true, imagenId = "Dumbbell_Shoulder_Press"),

        // ---- ESPALDA ----
        Exercise("remo-manc", "Remo con Mancuernas", "Espalda", "Dorsal + romboides + bíceps",
            listOf("Inclinado hacia adelante, espalda plana, rodillas un poco dobladas", "Lleva las mancuernas al ombligo", "Junta los omóplatos 1s"),
            "La espalda fuerte ayuda a mantener la posición de patinaje sin cansarse.",
            "Espalda plana, nunca curva.", "Espalda + postura", "3x10-12 • 45s", "ESPALDA", true, imagenId = "Bent_Over_Two-Dumbbell_Row"),
        Exercise("remo-un-brazo", "Remo a un Brazo", "Espalda", "Dorsal + romboides",
            listOf("Mano y rodilla apoyadas en el sofá", "Mancuerna sube hacia la cadera", "Baja lento"),
            "Apoyado es más seguro para la espalda.",
            "Peso ligero.", "Espalda", "3x10 c/brazo • 45s", "ESPALDA", true, imagenId = "One-Arm_Dumbbell_Row"),
        Exercise("pajaros", "Pájaros (Aperturas Inclinado)", "Espalda alta + hombro posterior", "Deltoide posterior + romboides",
            listOf("Inclinado, espalda plana, muñequeras o mancuernas muy ligeras", "Abre los brazos a los lados como alas", "Junta los omóplatos arriba"),
            "Postura erguida y hombros atrás.",
            "Muy ligero (0,5 kg).", "Postura", "3x10 • 45s", "ESPALDA", true, imagenId = "Reverse_Flyes"),
        Exercise("superman", "Superman", "Espalda baja", "Lumbares + glúteo + espalda alta",
            listOf("Boca abajo, brazos estirados al frente", "Sube brazos y piernas a la vez", "Mantén 2s y baja"),
            "Clave para patinadores: la espalda baja sostiene la posición agachada.",
            "Movimiento corto y controlado.", "Espalda fuerte", "3x8 • 40s", "ESPALDA", false, imagenId = "Superman"),
        Exercise("nadador-ytw", "Nadador Y-T-W", "Espalda alta + hombros", "Trapecio medio/bajo + romboides",
            listOf("Boca abajo, frente sobre una toalla", "Brazos en forma de Y, luego T, luego W", "Sube los brazos 2s en cada letra"),
            "Sin peso al inicio; con muñequeras de 0,5 kg cuando sea fácil.",
            "Sin dolor de hombro.", "Hombros sanos", "2x6 c/letra • 40s", "ESPALDA", false),

        // ---- CORE / ABDOMEN ----
        Exercise("plancha", "Plancha", "Core", "Abdomen + hombros",
            listOf("Antebrazos en el piso, codos bajo los hombros", "Cuerpo recto, glúteo apretado", "Respira normal"),
            "Mejor 20s perfectos que 40s con la cadera caída. Sube 5s cada semana.",
            "Seguro.", "Abdomen firme", "3x20-30s • 40s", "CORE", false, imagenId = "Plank"),
        Exercise("plancha-lateral", "Plancha Lateral", "Oblicuos", "Oblicuos + glúteo medio",
            listOf("De lado, antebrazo bajo el hombro", "Sube la cadera y mantén", "Cambia de lado"),
            "Rodilla de abajo apoyada si cuesta mucho.",
            "Seguro.", "Curvas del patinaje", "2x15-20s c/lado • 30s", "CORE", false, imagenId = "Side_Bridge"),
        Exercise("plancha-toques", "Plancha con Toque de Hombros", "Core anti-rotación", "Core + hombros",
            listOf("Plancha alta, pies separados", "Toca el hombro contrario", "Cadera lo más quieta posible"),
            "Abre más los pies si la cadera se mueve.",
            "Seguro.", "Estabilidad", "3x8 c/lado • 40s", "CORE", false),
        Exercise("dead-bug", "Bicho Muerto (Dead Bug)", "Core profundo", "Transverso + recto abdominal",
            listOf("Boca arriba, brazos al techo, rodillas a 90°", "Estira brazo y pierna contrarios sin despegar la espalda", "Vuelve y cambia de lado"),
            "El mejor ejercicio de abdomen para niños: fuerte y seguro para la espalda.",
            "Lumbar siempre pegada al piso.", "Abdomen profundo", "3x8 c/lado • 40s", "CORE", false, imagenId = "Dead_Bug"),
        Exercise("hollow", "Banana (Hollow Hold)", "Core", "Recto abdominal + transverso",
            listOf("Boca arriba, brazos estirados atrás", "Sube hombros y piernas un poco, forma de banana", "Lumbar pegada al piso"),
            "Si se arquea la espalda, dobla las rodillas.",
            "Lumbar pegada.", "Abdomen fuerte", "3x15-20s • 40s", "CORE", false),
        Exercise("crunch-inverso", "Crunch Inverso", "Abdomen bajo", "Recto abdominal inferior",
            listOf("Boca arriba, rodillas dobladas", "Lleva las rodillas al pecho despegando un poco la cadera", "Baja lento"),
            "Sin impulso, lento.",
            "Seguro.", "Abdomen bajo", "2x10 • 40s", "CORE", false, imagenId = "Reverse_Crunch"),
        Exercise("tijeras", "Tijeras", "Abdomen bajo", "Recto inferior + flexores de cadera",
            listOf("Boca arriba, manos bajo el glúteo", "Piernas estiradas un poco arriba del piso", "Mueve arriba y abajo alternando"),
            "Si molesta la espalda, sube más las piernas.",
            "Lumbar pegada.", "Abdomen bajo", "2x20s • 40s", "CORE", false, imagenId = "Flutter_Kicks"),
        Exercise("russian", "Giro Ruso", "Oblicuos", "Oblicuos + core",
            listOf("Sentado, rodillas dobladas, pies en el piso", "Tronco un poco atrás, espalda recta", "Gira a un lado y al otro"),
            "Sin peso. Pies en el piso.",
            "Espalda recta.", "Cintura firme", "2x10 c/lado • 40s", "CORE", false, imagenId = "Russian_Twist"),
        Exercise("escalador", "Escalador (Mountain Climbers)", "Core + quema", "Abdomen + hombros + cardio",
            listOf("Plancha alta, manos bajo hombros", "Rodillas al pecho alternando", "Cadera estable"),
            "Gran ejercicio para quemar y trabajar abdomen.",
            "Ritmo controlado.", "Quema + abdomen", "3x20s • 40s", "CORE", false, imagenId = "Mountain_Climbers"),

        // ---- PIERNA (solo en días sin patinaje) ----
        Exercise("sentadilla", "Sentadilla", "Pierna completa", "Cuádriceps + glúteo",
            listOf("Pies al ancho de hombros", "Cadera atrás como sentándose en una silla", "Sube empujando con los talones"),
            "Base de la posición de patinaje. Primero perfecta sin peso.",
            "Rodillas siguen la punta del pie.", "Piernas fuertes", "3x12 • 60s", "PIERNA", false, imagenId = "Bodyweight_Squat"),
        Exercise("sentadilla-goblet", "Sentadilla Goblet", "Pierna + core", "Cuádriceps + glúteo + core",
            listOf("Una mancuerna de 1 kg al pecho", "Baja la cadera atrás", "Pecho arriba"),
            "Solo si la sentadilla sin peso ya es perfecta.",
            "Rango cómodo.", "Piernas fuertes", "3x10 • 60s", "PIERNA", true, imagenId = "Goblet_Squat"),
        Exercise("zancada-atras", "Zancada Hacia Atrás", "Pierna unilateral", "Cuádriceps + glúteo + equilibrio",
            listOf("De pie, da un paso largo hacia atrás", "Baja la rodilla de atrás cerca del piso", "Vuelve al centro"),
            "Hacia atrás es más fácil y seguro que hacia adelante. Sin peso o tobilleras de 0,5 kg.",
            "Rodilla de adelante sobre el pie.", "Pierna + equilibrio", "2x8 c/pierna • 60s", "PIERNA", false, imagenId = "Dumbbell_Rear_Lunge"),
        Exercise("puente-gluteo", "Puente de Glúteo", "Glúteo", "Glúteo + isquiotibiales",
            listOf("Boca arriba, rodillas dobladas", "Sube la cadera apretando glúteos", "Mantén 2s y baja"),
            "El glúteo es el motor del empuje en el patín.",
            "Seguro.", "Empuje", "3x12 • 45s", "PIERNA", false, imagenId = "Butt_Lift_Bridge"),
        Exercise("puente-1pierna", "Puente a Una Pierna", "Glúteo unilateral", "Glúteo + estabilidad de cadera",
            listOf("Igual que el puente, una pierna estirada", "Sube la cadera sin que se incline", "Cambia de pierna"),
            "Cadera nivelada como en el patín.",
            "Seguro.", "Glúteo", "2x8 c/pierna • 45s", "PIERNA", false, imagenId = "Single_Leg_Glute_Bridge"),
        Exercise("pantorrilla", "Elevación de Talones", "Pantorrilla + tobillo", "Gemelos + sóleo",
            listOf("De pie, cerca de una pared", "Sube en punta de pies", "Baja lento contando 2"),
            "Tobillos fuertes = más control sobre las ruedas.",
            "Seguro.", "Tobillo fuerte", "3x15 • 40s", "PIERNA", false, imagenId = "Standing_Calf_Raises"),
        Exercise("patada-lateral-tob", "Elevación Lateral de Pierna con Tobillera", "Glúteo medio", "Glúteo medio + abductores",
            listOf("Acostado de lado", "Sube la pierna de arriba recta", "Baja lento"),
            "Tobillera de 0,5 kg. El glúteo medio da estabilidad en cada empuje.",
            "Peso ligero.", "Estabilidad", "2x10 c/lado • 40s", "PIERNA", true, imagenId = "Side_Leg_Raises"),
        Exercise("patada-atras-tob", "Patada de Glúteo con Tobillera", "Glúteo", "Glúteo mayor",
            listOf("En cuatro apoyos", "Empuja una pierna hacia atrás y arriba", "Sin arquear la espalda"),
            "Tobillera de 0,5 kg.",
            "Abdomen apretado.", "Glúteo", "3x10 c/lado • 40s", "PIERNA", true, imagenId = "Glute_Kickback"),

        // ---- OFF-SKATE ----
        Exercise("os-posicion", "Posición de Patinaje (Isométrico)", "Off-skate • activación", "Cuádriceps + glúteo + espalda",
            listOf("Rodillas dobladas, tronco inclinado al frente", "Espalda plana, manos atrás en la espalda", "Mantén la posición baja"),
            "La posición básica del patinador. Con el tiempo, más baja y más segundos.",
            "Rodillas sobre la punta del pie.", "Resistencia en posición", "3x20-30s • 40s", "OFF-SKATE", false),
        Exercise("os-patinador", "Saltos de Patinador", "Off-skate • quema de grasa", "Glúteo + piernas + equilibrio + cardio",
            listOf("Salta de lado de una pierna a la otra", "Aterriza suave en la pierna de afuera", "La otra pierna cruza atrás"),
            "Imita el empuje lateral del patín. Primero pasos, luego saltos cortos.",
            "Aterrizaje suave con rodilla doblada.", "Empuje + quema", "3x20s • 40s", "OFF-SKATE", false),
        Exercise("os-sentadilla-lateral", "Desplazamiento Lateral en Posición", "Off-skate", "Glúteo medio + cuádriceps",
            listOf("En posición de patinaje", "Paso largo lateral sin subir", "Junta y repite al otro lado"),
            "Con tobilleras de 0,5 kg cuando sea fácil.",
            "Mantén la altura baja.", "Empuje lateral", "3x8 c/lado • 45s", "OFF-SKATE", true),
        Exercise("os-equilibrio", "Equilibrio en Una Pierna", "Off-skate • control", "Tobillo + cadera + core",
            listOf("Posición de patinaje sobre una pierna", "La otra pierna estirada al lado o atrás", "Mantén sin tocar el piso"),
            "Cerca de una pared al principio. Luego con ojos cerrados unos segundos.",
            "Seguro.", "Equilibrio", "3x20s c/pierna • 30s", "OFF-SKATE", false),

        // ---- ESTIRAMIENTO ----
        Exercise("estiramiento", "Estiramiento Tren Superior", "Vuelta a la calma", "Pecho, hombros, brazos, espalda",
            listOf("Brazo cruzado al pecho", "Tríceps detrás de la cabeza", "Postura del niño (rodillas al piso, brazos al frente)", "Cobra suave para el abdomen"),
            "20s cada estiramiento, respirando lento.",
            "Sin dolor.", "Recuperar", "4-5 min", "ESTIRAMIENTO", false),
        Exercise("estiramiento-piernas", "Estiramiento de Piernas", "Vuelta a la calma", "Cuádriceps, isquios, glúteo, aductor, gemelo",
            listOf("Cuádriceps de pie (talón al glúteo)", "Isquios sentado, piernas estiradas", "Mariposa para aductores", "Gemelo contra la pared"),
            "Muy importante para un patinador: las piernas trabajan todos los días.",
            "Sin rebotes.", "Recuperar piernas", "5-6 min", "ESTIRAMIENTO", false, imagenId = "Standing_Gastrocnemius_Calf_Stretch")
    )

    val categorias = listOf("TODOS", "CALENTAMIENTO", "BRAZOS", "HOMBROS", "ESPALDA", "CORE", "PIERNA", "OFF-SKATE", "ESTIRAMIENTO")

    fun exerciseById(id: String): Exercise? = exerciseLibrary.find { it.id == id }
}
