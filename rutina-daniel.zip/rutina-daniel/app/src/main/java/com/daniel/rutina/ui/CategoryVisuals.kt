package com.daniel.rutina.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.ui.graphics.vector.ImageVector
import com.daniel.rutina.R
import com.daniel.rutina.ui.theme.AzulAccion
import com.daniel.rutina.ui.theme.NaranjaAlerta
import com.daniel.rutina.ui.theme.RojoAlta
import com.daniel.rutina.ui.theme.VerdeOk
import androidx.compose.ui.graphics.Color

/**
 * Ícono + color de miniatura según la categoría del ejercicio, para reconocer de un
 * vistazo el tipo de movimiento sin tener que abrir el video. No reemplaza una
 * ilustración paso a paso del ejercicio exacto, solo ayuda a ubicar rápido de qué se trata.
 */
object CategoryVisuals {

    /** Pictograma dibujado a mano para ejercicios sin foto real disponible. */
    fun localDrawableFor(exerciseId: String): Int? = when (exerciseId) {
        "plancha-toques" -> R.drawable.ic_plank_taps
        else -> null
    }

    fun iconFor(categoria: String): ImageVector = when (categoria) {
        "CALENTAMIENTO" -> Icons.Filled.DirectionsRun
        "BRAZOS" -> Icons.Filled.FitnessCenter
        "HOMBROS" -> Icons.Filled.FitnessCenter
        "ESPALDA" -> Icons.Filled.Accessibility
        "CORE" -> Icons.Filled.SelfImprovement
        "PIERNA" -> Icons.Filled.DirectionsRun
        "OFF-SKATE" -> Icons.Filled.DirectionsRun
        "ESTIRAMIENTO" -> Icons.Filled.SelfImprovement
        else -> Icons.Filled.FitnessCenter
    }

    fun colorFor(categoria: String): Color = when (categoria) {
        "CALENTAMIENTO" -> NaranjaAlerta
        "BRAZOS" -> RojoAlta
        "HOMBROS" -> AzulAccion
        "ESPALDA" -> VerdeOk
        "CORE" -> NaranjaAlerta
        "PIERNA" -> VerdeOk
        "OFF-SKATE" -> AzulAccion
        "ESTIRAMIENTO" -> VerdeOk
        else -> AzulAccion
    }
}
