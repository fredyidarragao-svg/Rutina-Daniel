package com.daniel.rutina.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.daniel.rutina.R
import com.daniel.rutina.ui.theme.AzulAccion
import com.daniel.rutina.ui.theme.Morado
import com.daniel.rutina.ui.theme.NaranjaAlerta
import com.daniel.rutina.ui.theme.RojoAlta
import com.daniel.rutina.ui.theme.Rosa
import com.daniel.rutina.ui.theme.Turquesa
import com.daniel.rutina.ui.theme.VerdeOk

/**
 * Dibujos, emojis y colores de cada ejercicio, categoría y día, para que Daniel reconozca
 * todo de un vistazo.
 */
object CategoryVisuals {

    /** Ilustración caricatura (dibujada para la app). Tiene prioridad sobre la foto. */
    fun localDrawableFor(exerciseId: String): Int? = when (exerciseId) {
        "movilidad" -> R.drawable.ex_movilidad
        "skipping" -> R.drawable.ex_skipping
        "gateo-oso" -> R.drawable.ex_gateo_oso
        "cangrejo" -> R.drawable.ex_cangrejo
        "flex-rodillas" -> R.drawable.ex_flex_rodillas
        "fondos-silla" -> R.drawable.ex_fondos_silla
        "nadador-ytw" -> R.drawable.ex_nadador_ytw
        "hollow" -> R.drawable.ex_hollow
        "os-posicion" -> R.drawable.ex_os_posicion
        "os-patinador" -> R.drawable.ex_os_patinador
        "os-sentadilla-lateral" -> R.drawable.ex_os_sentadilla_lateral
        "os-equilibrio" -> R.drawable.ex_os_equilibrio
        "estiramiento" -> R.drawable.ex_estiramiento
        "estiramiento-piernas" -> R.drawable.ex_estiramiento_piernas
        "plancha-toques" -> R.drawable.ex_plancha_toques
        "dead-bug" -> R.drawable.ex_dead_bug
        "superman" -> R.drawable.ex_superman
        "sentadilla" -> R.drawable.ex_sentadilla
        "puente-gluteo" -> R.drawable.ex_puente_gluteo
        "curl-manc" -> R.drawable.ex_curl_manc
        "elev-lateral" -> R.drawable.ex_elev_lateral
        else -> null
    }

    fun emojiFor(categoria: String): String = when (categoria) {
        "CALENTAMIENTO" -> "🔥"
        "BRAZOS" -> "💪"
        "HOMBROS" -> "🏋️"
        "ESPALDA" -> "🦸"
        "CORE" -> "🍫"
        "PIERNA" -> "🦵"
        "OFF-SKATE" -> "🛼"
        "ESTIRAMIENTO" -> "🧘"
        else -> "⭐"
    }

    fun labelFor(categoria: String): String = when (categoria) {
        "TODOS" -> "⭐ Todos"
        "CORE" -> "🍫 Abdomen"
        "PIERNA" -> "🦵 Piernas"
        else -> emojiFor(categoria) + " " + categoria.lowercase().replaceFirstChar { it.uppercase() }
    }

    fun iconFor(categoria: String): ImageVector = when (categoria) {
        "CALENTAMIENTO" -> Icons.Filled.DirectionsRun
        "BRAZOS" -> Icons.Filled.FitnessCenter
        "HOMBROS" -> Icons.Filled.FitnessCenter
        "ESPALDA" -> Icons.Filled.Accessibility
        "CORE" -> Icons.Filled.SelfImprovement
        "PIERNA" -> Icons.Filled.DirectionsRun
        "OFF-SKATE" -> Icons.Filled.DirectionsRun
        "ESTIRAMIENTO" -> Icons.Filled.SelfImprovement
        else -> Icons.Filled.FitnessCenter
    }

    fun colorFor(categoria: String): Color = when (categoria) {
        "CALENTAMIENTO" -> NaranjaAlerta
        "BRAZOS" -> RojoAlta
        "HOMBROS" -> Morado
        "ESPALDA" -> VerdeOk
        "CORE" -> Rosa
        "PIERNA" -> AzulAccion
        "OFF-SKATE" -> Turquesa
        "ESTIRAMIENTO" -> VerdeOk
        else -> AzulAccion
    }

    /** Color propio de cada día de la semana (arcoíris). */
    fun colorDia(dayId: String): Color = when (dayId) {
        "lun" -> AzulAccion
        "mar" -> Morado
        "mie" -> Turquesa
        "jue" -> NaranjaAlerta
        "vie" -> VerdeOk
        "sab" -> Rosa
        "dom" -> Color(0xFF00A3E0)
        else -> AzulAccion
    }

    fun emojiDia(deporte: String?, esDeporte: Boolean): String = when {
        deporte == "natación" -> "🏊"
        deporte == "patinaje" -> "🛼"
        !esDeporte -> "🧘"
        else -> "⭐"
    }
}
