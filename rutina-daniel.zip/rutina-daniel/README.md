# Rutina Daniel — V1 (Android nativo)

App hermana de **Rutina Fredy**: mismo modelo (Kotlin + Jetpack Compose, historial local con Room,
métricas del reloj vía Health Connect), con la rutina armada para **Daniel**: niño deportista de
7 años, 1,40 m, 30 kg, patinador.

## Semana de Daniel

| Día | Deporte | Qué se hace | Si NO practica (botón "Hoy no patiné") |
|---|---|---|---|
| Lunes | Patinaje 90 min | Solo marcar "¡Ya patiné!" | Off-skate + piernas + brazos (40 min) |
| Martes | Patinaje 90 min | Solo marcar "¡Ya patiné!" | Circuito quema off-skate + espalda (40 min) |
| Miércoles | Patinaje 90 min | Solo marcar "¡Ya patiné!" | Piernas fuertes + hombros (40 min) |
| Jueves | Patinaje 90 min | Solo marcar "¡Ya patiné!" | Equilibrio off-skate + core (40 min) |
| Viernes | Descanso | Rutina de estiramientos 20 min | — |
| Sábado | Patinaje 90 min | Solo marcar "¡Ya patiné!" | Circuito quema + piernas (35-40 min) |
| Domingo | Natación | Solo marcar "¡Ya nadé!" | Cuerpo completo (35 min) |

**Reglas de la rutina**

- Días de deporte: no hay rutina, solo el botón **"¡Ya patiné!"** / **"¡Ya nadé!"**. Patinaje = 90 min (se precarga en "Tiempo" al registrar métricas).
- Si Daniel no practica ese día, se toca **"Hoy no patiné"** y la app genera
  la rutina en casa, que sí incluye **fortalecimiento de piernas y off-skate**.
- Calentamiento **funcional** (movilidad, gateo de oso, cangrejo, saltos suaves): no usa bici.
- Los ejercicios marcados `ROT_*` **cambian cada semana** (ciclo de 4 semanas).
- Peso siempre **ligero**: mancuernas 0,5–1 kg (máx. 2 kg), muñequeras/tobilleras 0,5 kg. Si la
  técnica se pierde, se termina la serie.
- Objetivo de abdomen: se trabaja con core + circuitos de quema y su actividad diaria; en niños no se
  hacen dietas de restricción.

## Reloj (Health Connect)

La app lee frecuencia cardíaca, pasos, sueño y minutos de ejercicio desde **Health Connect**, que
recibe los datos de Mi Fitness / Zepp. Si el reloj de Daniel está vinculado a otro celular, la app
debe instalarse en ese celular.

## Compilar (sin computadora)

Igual que Rutina Fredy: subir este proyecto a un repositorio de GitHub (`rutina-daniel`) y la acción
**Compilar APK** genera el archivo `rutina-daniel-apk` en la pestaña *Actions*.

## Modo niño

- Colores claros y alegres, letra redondeada (Fredoka), botones grandes con efecto 3D.
- Dibujos de un niño haciendo cada ejercicio (21 ilustraciones propias) + fotos para el resto.
- Estrellas ⭐ por cada día completado y racha 🔥 de días seguidos.
- Trofeo y confeti al terminar la rutina o marcar el entreno.
