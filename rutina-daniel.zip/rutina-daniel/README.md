# Rutina Daniel — V1 (Android nativo)

App hermana de **Rutina Fredy**: mismo modelo (Kotlin + Jetpack Compose, historial local con Room,
métricas del reloj vía Health Connect), con la rutina armada para **Daniel**: niño deportista de
7 años, 1,40 m, 30 kg, patinador.

## Semana de Daniel

| Día | Deporte | Extra opcional (hasta 45 min) | Si NO practica (switch) |
|---|---|---|---|
| Lunes | Patinaje 90 min | Brazos + core | Off-skate + piernas + brazos (40 min) |
| Martes | Patinaje 90 min | Espalda + core | Circuito quema off-skate + espalda (40 min) |
| Miércoles | Patinaje 90 min | Hombros + brazos | Piernas fuertes + hombros (40 min) |
| Jueves | Patinaje 90 min | Espalda + abdomen | Equilibrio off-skate + core (40 min) |
| Viernes | Descanso | Rutina de estiramientos 20 min | — |
| Sábado | Patinaje 90 min | Circuito tren superior | Circuito quema + piernas (35-40 min) |
| Domingo | Natación | Core suave + estiramiento | Cuerpo completo (35 min) |

**Reglas de la rutina**

- Patinaje: 90 min (la app precarga 90 min en "Tiempo" al registrar métricas). En esos días las piernas **descansan**: la rutina es solo tren superior + core.
- Si Daniel no practica ese día, se activa el switch **"Daniel no practica … hoy"** y la app genera
  la rutina en casa, que sí incluye **fortalecimiento de piernas y off-skate**.
- Calentamiento **funcional** (movilidad, gateo de oso, cangrejo, saltos suaves): no usa bici.
- Los ejercicios marcados `ROT_*` **cambian cada semana** (ciclo de 4 semanas).
- Peso siempre **ligero**: mancuernas 0,5–1 kg (máx. 2 kg), muñequeras/tobilleras 0,5 kg. Si la
  técnica se pierde, se termina la serie.
- Objetivo de abdomen: se trabaja con core + circuitos de quema y su actividad diaria; en niños no se
  hacen dietas de restricción.

## Reloj (Health Connect)

La app lee frecuencia cardíaca, pasos, sueño y minutos de ejercicio desde **Health Connect**, que
recibe los datos de Mi Fitness / Zepp. Si el reloj de Daniel está vinculado a otro celular, la app
debe instalarse en ese celular.

## Compilar (sin computadora)

Igual que Rutina Fredy: subir este proyecto a un repositorio de GitHub (`rutina-daniel`) y la acción
**Compilar APK** genera el archivo `rutina-daniel-apk` en la pestaña *Actions*.
